from setuptools import setup

setup(
    name='fctrl',
    version='0.5.0',
    packages=[''],
    url='',
    license='',
    author='Matteo Ludwig',
    author_email='matteo.ludwig@gmail.com',
    description='A cool fan control system von debian based systems (and possibly others but idk)'
)
